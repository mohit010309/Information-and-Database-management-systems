SELECT customers.First_Name,customers.Last_Name,products.Name,products.Price,orders.Date_Time 
FROM ( (customers INNER JOIN orders ON customers.customerID=orders.customerID AND customers.Last_Name='Martin' )
INNER JOIN products on orders.productID=products.productID) ORDER BY Date_Time DESC;