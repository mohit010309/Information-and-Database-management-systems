-- non-optimized version
SELECT customers.customerID FROM customers,orders,products
WHERE customers.customerID=orders.customerID
AND products.CoffeeOrigin='Brazil'
AND (SELECT count(productID) AS cnt FROM products GROUP BY productID HAVING cnt > 2);