-- optimized version
SELECT * FROM (SELECT * FROM products WHERE Name='Espresso')SUB1,
(SELECT * FROM orders WHERE customerID=5)SUB2 WHERE SUB1.productID=SUB2.productID;
