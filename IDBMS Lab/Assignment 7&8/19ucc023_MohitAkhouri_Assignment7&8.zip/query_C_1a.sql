-- non-optimized version
SELECT * FROM products,orders
WHERE products.productID=orders.productID AND products.Name='Espresso'
AND orders.customerID=5;