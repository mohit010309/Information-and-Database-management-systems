-- theta join ( optimized version )
SELECT customers.customerID FROM customers INNER JOIN ( orders CROSS JOIN products )
ON customers.customerID=orders.customerID
WHERE products.CoffeeOrigin='Brazil';