-- non-optimized version
SELECT * FROM products
WHERE CoffeeOrigin='Indonesia' OR CoffeeOrigin='Brazil' AND Price<5;