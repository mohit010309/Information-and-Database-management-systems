-- commutative version of the optimized version
SELECT * FROM products WHERE productID IN (SELECT productID FROM products WHERE price<5) AND (CoffeeOrigin='Indonesia' OR CoffeeOrigin='Brazil');