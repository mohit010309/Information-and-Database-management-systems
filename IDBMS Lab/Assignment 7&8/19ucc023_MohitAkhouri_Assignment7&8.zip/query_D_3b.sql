-- optimized version (USING inner join)
SELECT customers.First_Name,customers.Last_Name FROM customers
INNER JOIN (SELECT orders.customerID , products.CoffeeOrigin FROM orders,products
WHERE orders.productID = products.productID
AND (products.CoffeeOrigin='Costa Rica' OR products.CoffeeOrigin='Indonesia'))SUB1
ON customers.customerID=SUB1.customerID;
