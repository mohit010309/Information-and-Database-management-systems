-- optimized version
SELECT * FROM products WHERE productID IN (SELECT productID FROM products WHERE CoffeeOrigin='Indonesia' OR 
CoffeeOrigin='Brazil') AND price < 5;