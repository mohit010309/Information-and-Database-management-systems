-- optimized version
SELECT count(productID) AS count FROM 
(SELECT * FROM products WHERE (CoffeeOrigin='Costa Rica' OR CoffeeOrigin='Brazil')) SUB WHERE 
(Name='Latte' OR Name='Espresso');
