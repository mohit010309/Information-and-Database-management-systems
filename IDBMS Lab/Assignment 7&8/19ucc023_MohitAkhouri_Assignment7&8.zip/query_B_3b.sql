-- theta join ( optimized version )
SELECT First_Name,Last_Name FROM customers INNER JOIN orders
ON customers.customerID=orders.customerID AND orders.productID=7;