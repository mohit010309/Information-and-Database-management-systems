-- non-optimized version (USING IN in sub query)
SELECT customers.First_Name,customers.Last_Name FROM customers,orders,products
WHERE customers.customerID=orders.customerID
AND orders.productID IN (SELECT productID FROM products WHERE CoffeeOrigin IN ('Costa Rica','Indonesia'));