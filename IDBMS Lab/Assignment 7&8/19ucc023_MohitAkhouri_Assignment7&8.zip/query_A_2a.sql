-- non-optimized version
SELECT * FROM customers WHERE ((First_Name LIKE 'S%' OR First_Name LIKE 'R%') AND gender='F');