-- non-optimized version (USING IN in sub query)
SELECT productID FROM orders,customers 
WHERE orders.customerID=customers.customerID
AND customers.Last_Name IN (SELECT Last_Name FROM customers WHERE Last_Name IN ('Taylor','Bluth','Armstrong'));