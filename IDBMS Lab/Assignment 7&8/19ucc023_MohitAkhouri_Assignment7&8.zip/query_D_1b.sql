-- optimized version (USING inner join)
SELECT productID FROM orders INNER JOIN customers 
ON orders.customerID=customers.customerID
WHERE customers.Last_Name='Taylor' OR customers.Last_Name='Bluth' OR customers.Last_Name='Armstrong';