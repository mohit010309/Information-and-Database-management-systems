-- cartesian product ( non-optimized version )
SELECT * FROM customers CROSS JOIN orders 
WHERE customers.customerID=orders.customerID AND
orders.Date_Time BETWEEN '2017-02-01' AND '2017-02-28'; 