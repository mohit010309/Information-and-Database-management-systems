-- optimized version (USING inner join)
SELECT orders.Date_Time FROM orders 
INNER JOIN customers ON orders.customerID = customers.customerID
WHERE (customers.First_Name='Katie' OR customers.First_Name='John' OR customers.First_Name='George');