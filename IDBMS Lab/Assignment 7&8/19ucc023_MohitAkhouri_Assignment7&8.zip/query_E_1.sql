SELECT customers.customerID,customers.First_Name,customers.Last_Name,products.CoffeeOrigin
FROM ( (customers INNER JOIN orders ON customers.customerID=orders.customerID) INNER JOIN products
ON orders.productID=products.productID) WHERE orders.Date_Time BETWEEN '2020-09-01' AND '2020-09-30';
