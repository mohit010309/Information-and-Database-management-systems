-- commutative version of optimized version
SELECT * FROM customers WHERE customerID IN (SELECT customerID FROM customers WHERE gender='F') 
AND (First_Name LIKE 'R%' OR First_Name LIKE 'S%');