-- non-optimized version
SELECT count(customers.customerID) AS count FROM customers,orders
WHERE customers.customerID=orders.customerID
AND orders.Date_Time BETWEEN '2020-09-01' AND '2020-09-30';