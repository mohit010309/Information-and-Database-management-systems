-- non-optimized version (USING IN in sub query)
SELECT orders.Date_Time FROM orders,
(SELECT customerID,Last_Name FROM customers WHERE First_Name IN ('Katie','John','George'))SUB1
WHERE orders.customerID=SUB1.customerID;