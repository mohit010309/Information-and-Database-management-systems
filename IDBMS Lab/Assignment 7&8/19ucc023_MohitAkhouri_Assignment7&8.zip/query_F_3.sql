SELECT customers.* FROM customers INNER JOIN orders
ON customers.customerID = orders.customerID
WHERE customers.customerID NOT IN (SELECT customerID FROM orders);