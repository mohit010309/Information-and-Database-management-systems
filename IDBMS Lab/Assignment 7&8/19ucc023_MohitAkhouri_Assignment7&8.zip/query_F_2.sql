SELECT orders.productID,customers.First_Name,customers.Last_Name,customers.customerID,orders.Date_Time
FROM customers INNER JOIN orders ON customers.customerID=orders.customerID 
ORDER BY orders.Date_Time ASC LIMIT 10;