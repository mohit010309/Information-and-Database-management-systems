-- optimized version
SELECT COUNT(SUB1.customerID) AS count FROM (SELECT customerID FROM customers)SUB1,
(SELECT customerID,Date_Time FROM orders WHERE Date_Time BETWEEN '2020-09-01' AND '2020-09-30')SUB2 
WHERE SUB1.customerID=sub2.customerID;