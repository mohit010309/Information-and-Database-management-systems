-- optimized version
SELECT * FROM customers WHERE customerID IN (SELECT customerID FROM customers WHERE 
First_Name LIKE 'R%' OR First_Name LIKE 'S%') AND gender='F';