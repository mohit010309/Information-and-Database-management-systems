-- optimized version
SELECT SUB1.* FROM (SELECT * FROM customers WHERE Gender='F')SUB1,
(SELECT customerID FROM orders)SUB2,(SELECT Name FROM products WHERE Name='Latte')SUB3
WHERE SUB1.customerID=SUB2.customerID;