-- non-optimized version
SELECT count(productID) FROM products WHERE (CoffeeOrigin='Costa Rica' OR CoffeeOrigin='Brazil') AND
(Name='Latte' OR Name='Espresso');