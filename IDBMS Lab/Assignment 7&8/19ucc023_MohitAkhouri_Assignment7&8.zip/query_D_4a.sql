-- non-optimized version (USING IN in sub query)
SELECT customers.First_Name,customers.Last_Name FROM customers,orders
WHERE customers.customerID=orders.customerID
AND orders.productID IN (1,3,5,7);