-- commutative version of optimized version
SELECT count(productID) AS count FROM 
(SELECT * FROM products WHERE (Name='Latte' OR Name='Espresso')) SUB WHERE 
(CoffeeOrigin='CostaRica' OR CoffeeOrigin='Brazil');

