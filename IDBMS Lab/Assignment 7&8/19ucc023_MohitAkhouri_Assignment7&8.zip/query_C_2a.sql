-- non-optimized version
SELECT customers.* FROM customers,orders,products
WHERE customers.customerID=orders.customerID
AND ( customers.Gender='F' AND products.Name='Latte');