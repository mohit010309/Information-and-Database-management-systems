-- optimized version (USING inner join)
SELECT customers.First_Name,customers.Last_Name FROM customers
INNER JOIN orders ON
customers.customerID=orders.customerID
WHERE orders.productID=1 OR orders.productID=3 OR orders.productID=5 OR orders.productID=7;