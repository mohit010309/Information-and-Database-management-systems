-- cartesian product ( non-optimized version )
SELECT customers.customerID FROM customers CROSS JOIN ( orders CROSS JOIN products )
WHERE customers.customerID=orders.customerID
AND products.CoffeeOrigin='Brazil';