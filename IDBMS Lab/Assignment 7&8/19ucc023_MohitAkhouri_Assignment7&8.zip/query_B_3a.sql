-- cartesian product ( non-optimized version )
SELECT First_Name,Last_Name FROM customers CROSS JOIN orders
WHERE customers.customerID=orders.customerID AND orders.productID=7;