-- optimized version
SELECT customers.customerID FROM customers,(SELECT CoffeeOrigin FROM products WHERE CoffeeOrigin='Brazil')SUB1,
(SELECT customerID FROM orders)SUB2 
WHERE customers.customerID=SUB2.customerID 
AND (SELECT count(productID) AS cnt FROM products GROUP BY (productID) HAVING cnt > 2);