SELECT SUM(Price) FROM (SELECT products.productID,products.Price as Price , orders.orderID
FROM products 
INNER JOIN orders ON
products.productID=orders.productID AND products.productID=1) SUB ;