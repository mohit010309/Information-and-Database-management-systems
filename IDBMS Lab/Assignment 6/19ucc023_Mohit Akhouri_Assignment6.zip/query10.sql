SELECT SUM(Price) FROM
(SELECT products.productID,products.Price FROM
products INNER JOIN
(SELECT customers.customerID,orders.productID,orders.customerID AS cid
FROM customers
INNER JOIN orders ON
customers.customerID=orders.customerID AND customers.First_Name='Chris')sub1 ON
products.productID=sub1.productID)sub2;