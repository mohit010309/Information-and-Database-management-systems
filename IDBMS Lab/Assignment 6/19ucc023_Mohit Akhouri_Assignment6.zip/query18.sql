SELECT customerID,First_Name,Last_Name,COUNT(customerID) AS "Number of products" FROM
(SELECT customers.First_Name,customers.Last_Name, customers.customerID AS customerID,orders.orderID,orders.customerID AS customer_ID
FROM customers
INNER JOIN orders ON
customers.customerID=orders.customerID)sub
GROUP BY customerID;