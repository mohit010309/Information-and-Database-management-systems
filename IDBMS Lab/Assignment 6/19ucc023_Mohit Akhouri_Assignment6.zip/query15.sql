SELECT count(customerID),First_Name FROM
(SELECT customers.First_Name,orders.orderID,orders.productID,orders.customerID
FROM customers INNER JOIN orders ON
customers.customerID=orders.customerID)sub
GROUP BY First_Name;