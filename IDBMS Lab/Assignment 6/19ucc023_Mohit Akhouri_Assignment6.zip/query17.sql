SELECT productID,Name,COUNT(Name) FROM
(SELECT products.Name, products.productID AS product_ID,orders.orderID,orders.productID AS productID
FROM products
INNER JOIN orders ON
products.productID=orders.productID)sub
GROUP BY productID;