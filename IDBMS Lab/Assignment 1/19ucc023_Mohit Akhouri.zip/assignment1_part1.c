#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>
#include <assert.h>
struct student
{
    int id;
    char name[30];
    char branch[20];
};
struct marks
{
    int id;
    float dbms;
    float ds;
    float c;
    float total;
    float perc;
};
int arr_id[10000000];
int pos=0;

void initialize();
void insert(FILE *fp);
int search_id(int srch);
void modify_name(FILE *fp);
void modify_branch(FILE *fp);
void delete_student(FILE *fp);
void search_by_branch(FILE *fp);
void search_by_name(FILE *fp);
void delete_marks_stud(int x);
void view_database();
void create_files();
//int check_status();
void delete_id_from_array(int del_id);
void main()
{
    char x;
    int stat_chk;
    FILE *fp;
    /*FILE *cr;
    cr=fopen("students.txt","w");
    fclose(cr);*/
    //stat_chk=check_status();
    create_files();
    initialize();
    printf("MENU FOR THE PROGRAM\n");
    printf("\n***********************************\n\n");
    printf("1 - insert students in database\n");
    printf("2 - modify the name of the student\n");
    printf("3 - modify the branch of the student\n");
    printf("4 - delete the student using student ID\n");
    printf("5 - search the list of students using branch\n");
    printf("6 - search the student by name\n");
    printf("7 - View the students database\n");
    printf("8 - exit\n");
    printf("\n***********************************\n");
    int ch;
    do
    {
        printf("Enter choice : ");
        scanf("%d%c",&ch,&x);
        if(ch==1)
            insert(fp);
        else if(ch==2)
            modify_name(fp);
        else if(ch==3)
            modify_branch(fp);
        else if(ch==4)
            delete_student(fp);
        else if(ch==5)
            search_by_branch(fp);
        else if(ch==6)
            search_by_name(fp);
        else if(ch==7)
            view_database();
        else if(ch==8)
            printf("Thank you\n");
        else
            printf("Wrong Choice\n");
    }while(ch!=8);
}
void insert(FILE *fp)
{
    int flag,chk;
    int ch;
    fp=fopen("students.txt","a");
    char name_stud[30];
    char name_branch[20];
    int id_no;
    //int i;
    char x;
    struct student temp;
    do
    {
        printf("Enter ID ( Integers Only ) : ");
        scanf("%d%c",&id_no,&x);
        flag=search_id(id_no);
        if(flag==1)
        {
            printf("Enter student name : ");
            scanf("%[^\n]%*c",name_stud);
            printf("Enter Branch of the student : ");
            scanf("%[^\n]%*c",name_branch);
            temp.id=id_no;
            strcpy(temp.name,name_stud);
            strcpy(temp.branch,name_branch);
            fwrite(&temp,sizeof(struct student),1,fp);
            arr_id[pos]=id_no;
            pos++;
        }
        else
        {
            printf("ID ALREADY EXISTS ! \n");
            /*printf("Do you want to try again ( 1 for YES , 0 for NO ): ");
            scanf("%d",&chk);
            if(chk==1)
                i--;*/
        }
        printf("Do you want to insert again : ( 1 for YES 0 for NO ) : ");
        scanf("%d",&ch);
    }while(ch!=0);
    printf("INSERTION COMPLETED ! \n");
    fclose(fp);
}
int search_id(int srch)
{
    int flag=1;
    int i;
    for(i=0;i<pos;i++)
    {
        if(arr_id[i]==srch)
        {
            flag=0;
            break;
        }
    }
    return flag; //0 if found 1 if not found
}
void initialize()
{
    FILE *fp;
    struct student temp;
    fp=fopen("students.txt","r");
    while(fread(&temp,sizeof(struct student),1,fp))
    {
        arr_id[pos]=temp.id;
        pos++;
    }
    fclose(fp);
}
void modify_name(FILE *fp)
{
    char x;
    fp=fopen("students.txt","r");
    FILE *fp1=fopen("temp.txt","w");
    struct student temp;
    char new_name[30];
    int id_no;
    printf("Enter ID No. whose NAME you want to change : ");
    scanf("%d%c",&id_no,&x);
    int flag;
    flag=search_id(id_no);
    if(flag==1)
    {
        printf("ID doesn't exists ! \n");
        fclose(fp);
        fclose(fp1);
    }
    else
    {
        printf("Enter new STUDENT name : ");
        scanf("%[^\n]%*c",new_name);
        while(fread(&temp,sizeof(struct student),1,fp))
        {
            if(temp.id==id_no)
            {
                strcpy(temp.name,new_name);
            }
            fwrite(&temp,sizeof(struct student),1,fp1);
        }
        printf("STUDENT NAME CHANGED SUCCESSFULLY ! \n");
        fclose(fp);
        fclose(fp1);
        remove("students.txt");
        rename("temp.txt","students.txt");
    }

}
void modify_branch(FILE *fp)
{
    char x;
    fp=fopen("students.txt","r");
    FILE *fp1=fopen("temp.txt","w");
    struct student temp;
    char new_branch[20];
    int id_no;
    printf("Enter ID No. whose BRANCH you want to change : ");
    scanf("%d%c",&id_no,&x);
    int flag;
    flag=search_id(id_no);
    if(flag==1)
    {
        printf("ID doesn't exists ! \n");
        fclose(fp);
        fclose(fp1);
    }
    else
    {
        printf("Enter new BRANCH name : ");
        scanf("%[^\n]%*c",new_branch);
        while(fread(&temp,sizeof(struct student),1,fp))
        {
            if(temp.id==id_no)
            {
                strcpy(temp.branch,new_branch);
            }
            fwrite(&temp,sizeof(struct student),1,fp1);
        }
        printf("BRANCH NAME CHANGED SUCCESSFULLY ! \n");
        fclose(fp);
        fclose(fp1);
        remove("students.txt");
        rename("temp.txt","students.txt");
    }

}
void delete_student(FILE *fp)
{
    struct student temp;
    FILE *fp1;
    fp=fopen("students.txt","r");
    fp1=fopen("temp.txt","w");
    char x; //for \n ( new line ) purpose
    int id_no;
    printf("Enter ID of student : ");
    scanf("%d%c",&id_no,&x);
    int flag;
    flag=search_id(id_no);
    if(flag==1)
        printf("ID doesn't exists\n");
    else
    {
        delete_id_from_array(id_no);
        while(fread(&temp,sizeof(struct student),1,fp))
        {
            if(temp.id!=id_no)
            {
                fwrite(&temp,sizeof(struct student),1,fp1);
            }
        }
        fclose(fp);
        fclose(fp1);
        remove("students.txt");
        rename("temp.txt","students.txt");
        printf("STUDENT DELETED SUCCESSFULLY !\n");
        delete_marks_stud(id_no);
    }
    fclose(fp);
    fclose(fp1);
}
void search_by_branch(FILE *fp)
{
    int tot=0,i;
    char branch_name[20];
    printf("Enter Branch name : ");
    scanf("%[^\n]%*c",branch_name);
    fp=fopen("students.txt","r");
    struct student temp;
    struct student arr[1000];
    int x=0;
    while(fread(&temp,sizeof(struct student),1,fp))
    {
        if(strcmp(temp.branch,branch_name)==0)
        {
            arr[x]=temp;
            x++;
            tot++;
        }

    }
    fclose(fp);
    if(tot==0)
        printf("The BRANCH does not exists ! \n");
    else
    {
        printf("The list of students are : \n\n");
        printf("%-10s %-30s\n\n","ID","NAME");
        for(i=0;i<x;i++)
        {
            printf("%-10d %-30s\n",arr[i].id,arr[i].name);
        }
    }
    printf("\n");
}
void search_by_name(FILE *fp)
{
    fp=fopen("students.txt","r");
    struct student temp;
    struct student temp1[10000];
    int x=0;
    char name_stud[30];
    printf("enter NAME of student : ");
    scanf("%[^\n]%*c",name_stud);
    int flag=0;
    while(fread(&temp,sizeof(struct student),1,fp))
    {
        if(strcmp(temp.name,name_stud)==0)
        {
            temp1[x]=temp;
            x++;
            flag=1;
            //break;
        }
    }
    if(flag==1)
    {
        printf("STUDENT FOUND !\n\n");
        printf("%-10s %-30s %-25s\n\n","ID","NAME","BRANCH");
        for(int i=0;i<x;i++)
            printf("%-10d %-30s %-25s\n",temp1[i].id,temp1[i].name,temp1[i].branch);
    }
    else
        printf("Student not found !\n");
    printf("\n");
    fclose(fp);
}
void delete_marks_stud(int x)
{
    FILE *fp1,*fp2;
    fp1=fopen("marks.txt","r");
    fp2=fopen("temp3.txt","w");
    struct marks temp;
    while(fread(&temp,sizeof(struct marks),1,fp1))
    {
        if(temp.id!=x)
        {
            fwrite(&temp,sizeof(struct marks),1,fp2);
        }
    }
    fclose(fp1);
    fclose(fp2);
    remove("marks.txt");
    rename("temp3.txt","marks.txt");
}
void view_database()
{
    FILE *fp;
    fp=fopen("students.txt","r");
    struct student temp;
    printf("%-10s %-30s %-25s\n\n","ID","NAME","BRANCH");
    while(fread(&temp,sizeof(struct student),1,fp))
    {
        printf("%-10d %-30s %-25s\n",temp.id,temp.name,temp.branch);
    }
    fclose(fp);
    printf("\n");
}
void create_files()
{
    FILE *fp=fopen("students.txt","a");
    fclose(fp);
    FILE *fp1=fopen("marks.txt","a");
    fclose(fp1);
}
/*int check_status()
{
    int flag=0;
    FILE *fp1,*fp2;
    fp1=fopen("students.txt","r");
    fp2=fopen("marks.txt","r");
    if(fp1 && fp2)
        flag=1;
    fclose(fp1);
    fclose(fp2);
    return flag;
}*/
void delete_id_from_array(int del_id)
{
    int i;
    for(i=0;i<pos;i++)
    {
        if(arr_id[i]==del_id)
        {
            arr_id[i]=-1;
            break;
        }
    }
}


