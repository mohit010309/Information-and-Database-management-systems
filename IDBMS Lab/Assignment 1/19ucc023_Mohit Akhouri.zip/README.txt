Name = Mohit Akhouri
Roll no = 19ucc023
Subject = IDBMS

This assignment was submitted on 16th August,2020

assignment1_part1 is about " modifications of students.txt file / database "
assignment1_part2 is about " modifications of marks.txt file / database "
