#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>
#include <assert.h>
struct marks
{
    int id;
    float dbms;
    float ds;
    float c;
    float total;
    float perc;
};
struct student
{
    int id;
    char name[30];
    char branch[20];
};
int id_reg[10000000];
int id_reg_pos=0;
int marks_reg[100000000];
int marks_reg_pos=0;
void initialize();
void insert_marks(FILE *fp);
int search_id(int srch);
int search_marks_list(int srch);
void update_marks(FILE *fp);
void show_marks(FILE *fp);
void show_perc_threshold(FILE *fp);
void show_branch_perc_threshold(FILE *fp);
void view_marks();
void initialize_markslist();
void create_files();
//int check_status();
void main()
{
    FILE *fp;
    //char x;
    int stat_chk;
    create_files();
    initialize();
    initialize_markslist();
    printf("MENU FOR THE PROGRAM\n");
    printf("\n***********************************\n\n");
    printf("1 - insert marks of registered students\n");
    printf("2 - update the marks\n");
    printf("3 - show the marks list using student id\n");
    printf("4 - search the students with percentage above a threshold\n");
    printf("5 - search the students of a particular branch with percentage above a threshold\n");
    printf("6 - View the marks database\n");
    printf("7 - exit\n");
    printf("\n***********************************\n");
    int ch;
    do
    {
        printf("Enter choice : ");
        scanf("%d",&ch);
        if(ch==1)
            insert_marks(fp);
        else if(ch==2)
            update_marks(fp);
        else if(ch==3)
            show_marks(fp);
        else if(ch==4)
            show_perc_threshold(fp);
        else if(ch==5)
            show_branch_perc_threshold(fp);
        else if(ch==6)
            view_marks();
        else if(ch==7)
            printf("Thank you\n");
        else
            printf("Wrong choice!\n");
    }while(ch!=7);

}
void initialize()
{
    FILE *fp;
    fp=fopen("students.txt","r");
    struct student temp;
    while(fread(&temp,sizeof(struct student),1,fp))
    {
        id_reg[id_reg_pos]=temp.id;
        id_reg_pos++;
    }
    fclose(fp);
}
void insert_marks(FILE *fp)
{
    int id_no;
    int flag,flag2;
    float m1,m2,m3;
    struct marks temp;
    fp=fopen("marks.txt","a");
    int ch;
    do
    {
        printf("Enter ID of the student : ");
        scanf("%d",&id_no);
        flag=search_id(id_no);
        if(flag==0)
            printf("The student is not a REGISTERED STUDENT \n");
        else
        {
            flag2=search_marks_list(id_no);
            if(flag2==1)
                printf("MARKS ALREADY REGISTERED ! \n");
            else
            {
                /*id_reg[id_reg_pos]=id_no;
                id_reg_pos++;*/
                marks_reg[marks_reg_pos]=id_no;
                marks_reg_pos++;
                printf("Enter marks in DBMS : ");
                scanf("%f",&m1);
                if(m1>100 || m1<0)
                {
                    printf("Marks cannot exceed 100 or less than 0 ! \n");
                    printf("Enter marks again ! \n");
                    while(m1>100 || m1<0)
                    {
                        printf("Enter marks in DBMS : ");
                        scanf("%f",&m1);
                        if(m1>100 || m1<0)
                        {
                            printf("Marks cannot exceed 100 or less than 0 ! \n");
                            printf("Enter marks again ! \n");
                        }
                    }
                }
                printf("Enter marks in DS : ");
                scanf("%f",&m2);
                if(m2>100 || m2<0)
                {
                    printf("Marks cannot exceed 100 or less than 0 ! \n");
                    printf("Enter marks again ! \n");
                    while(m2>100 || m2<0)
                    {
                        printf("Enter marks in DS : ");
                        scanf("%f",&m2);
                        if(m2>100 || m2<0)
                        {
                            printf("Marks cannot exceed 100 or less than 0 ! \n");
                            printf("Enter marks again ! \n");
                        }
                    }
                }
                printf("Enter marks in C : ");
                scanf("%f",&m3);
                if(m3>100 || m3<0)
                {
                    printf("Marks cannot exceed 100 or less than 0 ! \n");
                    printf("Enter marks again ! \n");
                    while(m3>100 || m3<0)
                    {
                        printf("Enter marks in C : ");
                        scanf("%f",&m3);
                        if(m3>100 || m3<0)
                        {
                            printf("Marks cannot exceed 100 or less than 0 ! \n");
                            printf("Enter marks again ! \n");
                        }
                    }
                }
                temp.id=id_no;
                temp.dbms=m1;
                temp.ds=m2;
                temp.c=m3;
                temp.total=m1+m2+m3;
                temp.perc=(temp.total*100.0)/300.0;
                fwrite((char *)&temp,sizeof(struct marks),1,fp);
            }
        }
        printf("Do you want to continue ( 1 for YES 0 for NO ) : ");
        scanf("%d",&ch);

    }while(ch!=0);
    fclose(fp);
}
int search_id(int srch)
{
    int flag=0;
    int i;
    for(i=0;i<id_reg_pos;i++)
    {
        if(id_reg[i]==srch)
        {
            flag=1;
            break;
        }
    }
    return flag; // 0 if not found , 1 if found
}
int search_marks_list(int srch)
{
    /*FILE *fp;
    int flag=0;
    fp=fopen("marks.txt","r");
    struct marks temp;
    while(fread(&temp,sizeof(struct marks),1,fp))
    {
        if(temp.id==srch)
        {
            flag=1;
            break;
        }
    }
    fclose(fp);
    return flag;*/
    int flag=0;
    int i;
    for(i=0;i<marks_reg_pos;i++)
    {
        if(marks_reg[i]==srch)
        {
            flag=1;
            break;
        }
    }
    return flag;
}
void update_marks(FILE *fp)
{
    float m1,m2,m3;
    int ch;
    fp=fopen("marks.txt","r");
    FILE *fp1;
    fp1=fopen("temp1.txt","w");
    struct marks temp,temp1;
    int id_no;
    printf("Enter ID of the student : ");
    scanf("%d",&id_no);
    int flag;
    flag=search_marks_list(id_no);
    if(flag==0)
    {
        printf("STUDENT NOT REGISTERED !\n");
        fclose(fp);
        fclose(fp1);
    }
    else
    {
        while(fread(&temp,sizeof(struct marks),1,fp))
        {
            if(temp.id==id_no)
                break;
        }
        printf("1 - UPDATE MARKS OF DBMS\n");
        printf("2 - UPDATE MARKS OF DS\n");
        printf("3 - UPDATE MARKS OF C\n");
        printf("4 - EXIT\n");
        printf("\n");
        do
        {
            printf("Enter choice : ");
            scanf("%d",&ch);
            if(ch==1)
            {
                printf("Enter new marks of DBMS : ");
                scanf("%f",&m1);
                if(m1>100 || m1<0)
                {
                    printf("Marks cannot exceed 100 or less than 0 ! \n");
                    printf("Enter marks again ! \n");
                    while(m1>100 || m1<0)
                    {
                        printf("Enter new marks in DBMS : ");
                        scanf("%f",&m1);
                        if(m1>100 || m1<0)
                        {
                            printf("Marks cannot exceed 100 or less than 0 ! \n");
                            printf("Enter marks again ! \n");
                        }
                    }
                }
                temp.dbms=m1;
            }
            else if(ch==2)
            {
                printf("Enter new marks of DS : ");
                scanf("%f",&m2);
                if(m2>100 || m2<0)
                {
                    printf("Marks cannot exceed 100 or less than 0 ! \n");
                    printf("Enter marks again ! \n");
                    while(m2>100 || m2<0)
                    {
                        printf("Enter new marks in DS : ");
                        scanf("%f",&m2);
                        if(m2>100 || m2<0)
                        {
                            printf("Marks cannot exceed 100 or less than 0 ! \n");
                            printf("Enter marks again ! \n");
                        }
                    }
                }
                temp.ds=m2;
            }
            else if(ch==3)
            {
                printf("Enter new marks of C : ");
                scanf("%f",&m3);
                if(m3>100 || m3<0)
                {
                    printf("Marks cannot exceed 100 or less than 0 ! \n");
                    printf("Enter marks again ! \n");
                    while(m3>100 || m3<0)
                    {
                        printf("Enter new marks in C : ");
                        scanf("%f",&m3);
                        if(m3>100 || m3<0)
                        {
                            printf("Marks cannot exceed 100 or less than 0 ! \n");
                            printf("Enter marks again ! \n");
                        }
                    }
                }
                temp.c=m3;
            }
            else if(ch==4)
                printf("MARKS UPDATED !\n");
            else
                printf("Wrong choice\n");

        }while(ch!=4);
        temp.total=temp.dbms+temp.ds+temp.c;
        temp.perc=(temp.total*100.0)/300.0;
        fseek(fp,0,SEEK_SET);
        while(fread(&temp1,sizeof(struct marks),1,fp))
        {
            if(temp1.id==id_no)
            {
                fwrite(&temp,sizeof(struct marks),1,fp1);
            }
            else
            {
                fwrite(&temp1,sizeof(struct marks),1,fp1);
            }
        }
        fclose(fp);
        fclose(fp1);
        remove("marks.txt");
        rename("temp1.txt","marks.txt");
    }

}
void show_marks(FILE *fp)
{
    struct marks temp;
    fp=fopen("marks.txt","r");
    int id_no;
    printf("Enter ID number : ");
    scanf("%d",&id_no);
    int flag;
    flag=search_marks_list(id_no);
    if(flag==0)
        printf("STUDENT NOT RESGISTERED !\n");
    else
    {
        printf("%-8s %-8s %-8s %-8s %-8s %-15s\n","ID","DBMS","DS","C","TOTAL","PERCENTAGE");
        while(fread(&temp,sizeof(struct marks),1,fp))
        {
            if(temp.id==id_no)
                break;
        }
        printf("%-8d %-8.2f %-8.2f %-8.2f %-8.2f %-15.2f\n",temp.id,temp.dbms,temp.ds,temp.c,temp.total,temp.perc);
    }
    fclose(fp);
    printf("\n");
}
void show_perc_threshold(FILE *fp)
{
    fp=fopen("marks.txt","r");
    int flag=0;
    float threshold_perc;
    printf("Enter threshold percentage : ");
    scanf("%f",&threshold_perc);
    struct marks temp;
    struct marks arr[10000];
    int pos=0,i;
    while(fread(&temp,sizeof(struct marks),1,fp))
    {
        if(temp.perc>threshold_perc)
        {
            flag=1;
            arr[pos]=temp;
            pos++;
        }
    }
    fclose(fp);
    if(flag==0)
        printf("NO STUDENT FOUND ! \n");
    else
    {
        printf("The list of students is : \n\n");
        printf("%-8s %-8s %-8s %-8s %-8s %-15s\n","ID","DBMS","DS","C","TOTAL","PERCENTAGE");
        for(i=0;i<pos;i++)
        {
            printf("%-8d %-8.2f %-8.2f %-8.2f %-8.2f %-15.2f\n",arr[i].id,arr[i].dbms,arr[i].ds,arr[i].c,arr[i].total,arr[i].perc);
        }
    }
    printf("\n");
}
void show_branch_perc_threshold(FILE *fp)
{
    char x;
    int i;
    int j;
    fp=fopen("marks.txt","r");
    FILE *fp1;
    fp1=fopen("students.txt","r");
    char br_name[20];
    int id_br[10000];
    int pos=0;
    struct student temp;
    struct marks temp1;
    struct marks arr[10000];
    int arr_pos=0;
    printf("Enter branch name : ");
    scanf("%c",&x);
    scanf("%[^\n]%*c",br_name);
    while(fread(&temp,sizeof(struct student),1,fp1))
    {
        if(strcmp(temp.branch,br_name)==0)
        {
            id_br[pos]=temp.id;
            pos++;
        }
    }
    fclose(fp1);
    if(pos==0)
    {
        printf("BRANCH NOT FOUND !\n");
        fclose(fp);
    }
    else
    {
        float thresh_perc;
        printf("Enter threshold : ");
        scanf("%f",&thresh_perc);
        int totflag=0;
        while(fread(&temp1,sizeof(struct marks),1,fp))
        {
            for(j=0;j<pos;j++)
            {
                if(temp1.id==id_br[j] && temp1.perc>thresh_perc)
                {
                    totflag=1;
                    arr[arr_pos]=temp1;
                    arr_pos++;
                    break;
                }
            }

        }
        fclose(fp);
        if(totflag==0)
            printf("NO STUDENT FOUND !\n");
        else
        {
            printf("The List of students are : \n");
            printf("%-8s %-8s %-8s %-8s %-8s %-15s\n","ID","DBMS","DS","C","TOTAL","PERCENTAGE");
            for(i=0;i<arr_pos;i++)
            {
                printf("%-8d %-8.2f %-8.2f %-8.2f %-8.2f %-15.2f\n",arr[i].id,arr[i].dbms,arr[i].ds,arr[i].c,arr[i].total,arr[i].perc);
            }
        }
    }
    printf("\n");
}
void view_marks()
{
    FILE *fp;
    struct marks temp;
    fp=fopen("marks.txt","r");
    printf("%-8s %-8s %-8s %-8s %-8s %-15s\n","ID","DBMS","DS","C","TOTAL","PERCENTAGE");
    while(fread(&temp,sizeof(struct marks),1,fp))
    {
        printf("%-8d %-8.2f %-8.2f %-8.2f %-8.2f %-15.2f\n",temp.id,temp.dbms,temp.ds,temp.c,temp.total,temp.perc);
    }
    fclose(fp);
}
void initialize_markslist()
{
    FILE *fp;
    fp=fopen("marks.txt","r");
    struct marks temp;
    while(fread(&temp,sizeof(struct marks),1,fp))
    {
        marks_reg[marks_reg_pos]=temp.id;
        marks_reg_pos++;
    }
    fclose(fp);
}
void create_files()
{
    FILE *fp=fopen("students.txt","a");
    fclose(fp);
    FILE *fp1=fopen("marks.txt","a");
    fclose(fp1);
}
/*int check_status()
{
    int flag=0;
    FILE *fp1,*fp2;
    fp1=fopen("students.txt","r");
    fp2=fopen("marks.txt","r");
    if(fp1 && fp2)
        flag=1;
    fclose(fp1);
    fclose(fp2);
    return flag;
}
*/
