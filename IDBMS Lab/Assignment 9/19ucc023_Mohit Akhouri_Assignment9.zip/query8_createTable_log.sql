CREATE TABLE log (
	id INT ,
    name VARCHAR(5),
    event VARCHAR(9)
    );
DESCRIBE log;