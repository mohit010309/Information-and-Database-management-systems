CREATE TRIGGER insert_log
AFTER INSERT 
ON t1
FOR EACH ROW
INSERT INTO log VALUES(new.id,new.name,'insert');
SHOW triggers;