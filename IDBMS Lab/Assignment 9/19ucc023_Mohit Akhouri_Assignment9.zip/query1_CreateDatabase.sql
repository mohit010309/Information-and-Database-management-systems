CREATE DATABASE trigger_db;
USE trigger_db;
SHOW DATABASES;
