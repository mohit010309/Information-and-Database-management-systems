CREATE TRIGGER o_update_log
BEFORE UPDATE
ON t1
FOR EACH ROW
INSERT INTO log VALUES(old.id,old.name,'oupdate');
SHOW triggers;