CREATE TRIGGER delete_log
BEFORE DELETE 
ON t1
FOR EACH ROW
INSERT INTO log VALUES(old.id,old.name,'delete');
SHOW triggers;