CREATE TRIGGER update_log
AFTER UPDATE
ON t1
FOR EACH ROW
INSERT INTO log VALUES(new.id,new.name,'update');
SHOW triggers;