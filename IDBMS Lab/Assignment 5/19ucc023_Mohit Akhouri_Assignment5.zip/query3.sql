SELECT productID,customerID,Date_Time 
FROM orders
WHERE Date_Time BETWEEN '2017-01-01' AND '2017-01-07';