SELECT products.Name,products.Price,orders.Date_Time 
FROM orders
INNER JOIN products ON products.productID=orders.productID
WHERE orders.productID=5
ORDER BY Date_Time DESC;