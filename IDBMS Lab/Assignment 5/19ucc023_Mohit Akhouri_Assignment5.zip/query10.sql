SELECT * FROM products 
ORDER BY Price ASC;