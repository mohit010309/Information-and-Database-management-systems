SELECT orders.orderID,customers.First_Name,customers.Last_Name,customers.ContactNumber,orders.Date_Time
FROM orders
LEFT JOIN customers ON customers.customerID=orders.orderID
ORDER BY orders.Date_Time DESC
LIMIT 10;