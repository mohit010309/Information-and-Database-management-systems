select distinct customers.First_Name,customers.ContactNumber 
from customers
inner join orders on orders.productID=1;