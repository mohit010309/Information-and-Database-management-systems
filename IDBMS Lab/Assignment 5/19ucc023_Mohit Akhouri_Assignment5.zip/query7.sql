SELECT * FROM customers WHERE Last_Name LIKE '%o';
