SELECT orders.orderID,customers.First_Name,customers.Last_Name,customers.ContactNumber,orders.Date_Time
FROM customers 
LEFT JOIN orders ON orders.customerID=customers.customerID
ORDER BY orders.Date_Time DESC
LIMIT 10;