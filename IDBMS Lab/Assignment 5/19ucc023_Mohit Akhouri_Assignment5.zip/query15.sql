SELECT * FROM customers
WHERE customerID>=6
LIMIT 5;