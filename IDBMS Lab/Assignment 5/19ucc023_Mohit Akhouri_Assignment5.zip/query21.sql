SELECT orders.orderID,customers.First_Name,customers.Last_Name,customers.ContactNumber,orders.Date_Time
FROM orders
INNER JOIN customers ON customers.customerID=orders.customerID
ORDER BY Date_Time DESC
LIMIT 10;