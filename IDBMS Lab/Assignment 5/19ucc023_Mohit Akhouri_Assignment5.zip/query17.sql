SELECT Name AS 'Product Name',
Price,
CoffeeOrigin AS Country
FROM products;