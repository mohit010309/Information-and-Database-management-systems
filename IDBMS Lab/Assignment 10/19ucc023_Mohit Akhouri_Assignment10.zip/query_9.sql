UPDATE Perf_Income
SET total_income=100000
WHERE performerName='Jimmy Buffett';
SELECT * FROM Perf_Income;