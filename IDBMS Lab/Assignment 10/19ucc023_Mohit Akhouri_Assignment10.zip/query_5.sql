CREATE VIEW Perf_Income AS
SELECT performers.performerName,arenas.ArenaName,concerts.ConcertDate,
concerts.TicketPrice*(0.10)*arenas.ArenaCapacity*(0.80) AS total_income
FROM activities INNER JOIN performers ON performers.performerID=activities.activityID
INNER JOIN concerts ON concerts.performerID=performers.performerID
INNER JOIN arenas ON arenas.arenaID=concerts.arenaID;

SHOW FULL TABLES 
WHERE table_type = 'VIEW';