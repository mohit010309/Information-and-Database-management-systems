INSERT INTO performers VALUES (8,'Ken Thomson','Washington Road','Washington DC','WD',32895,6);
SELECT * FROM performers;