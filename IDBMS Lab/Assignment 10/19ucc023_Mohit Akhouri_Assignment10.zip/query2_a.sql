SELECT performers.PerformerName,ActivityName 
FROM performers
INNER JOIN activities ON
performers.ActivityID=activities.ActivityID;