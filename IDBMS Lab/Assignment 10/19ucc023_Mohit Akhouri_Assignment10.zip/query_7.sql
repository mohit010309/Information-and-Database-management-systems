SELECT performers.performerName,arenas.ArenaName,concerts.ConcertDate,
concerts.TicketPrice*0.10*arenas.arenaCapacity*0.80 AS total_income
FROM performers INNER JOIN concerts ON concerts.performerID=performers.performerID
INNER JOIN arenas ON arenas.arenaID=concerts.arenaID
ORDER BY total_income DESC LIMIT 8;