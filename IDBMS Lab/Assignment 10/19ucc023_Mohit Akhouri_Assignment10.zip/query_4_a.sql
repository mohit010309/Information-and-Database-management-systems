UPDATE Act_perf
SET PerformerName='Harry Chapinn'
WHERE PerformerName='Harry Chapin';