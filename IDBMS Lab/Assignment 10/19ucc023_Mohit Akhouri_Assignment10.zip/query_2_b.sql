CREATE VIEW Act_perf
AS
SELECT performers.PerformerName,ActivityName 
FROM performers
INNER JOIN activities ON
performers.ActivityID=activities.ActivityID;

SHOW FULL TABLES 
WHERE table_type = 'VIEW';
