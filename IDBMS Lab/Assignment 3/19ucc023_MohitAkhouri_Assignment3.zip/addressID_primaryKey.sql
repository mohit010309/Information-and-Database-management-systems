ALTER TABLE addresses
ADD PRIMARY KEY (`addressID`);
DESCRIBE addresses;