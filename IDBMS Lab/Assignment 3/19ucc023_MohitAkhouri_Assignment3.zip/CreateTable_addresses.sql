CREATE TABLE `test`.`addresses` (
	`addressID` INT NOT NULL,
    `HouseNumber` INT NULL,
    `City` VARCHAR(45) NULL,
    `PostCode` INT NULL
    );
SHOW tables;