CREATE TABLE `test`.`people` (
	`peopleID` INT NOT NULL,
    `FirstName` VARCHAR(45) NOT NULL,
    `LastName` VARCHAR(45) NULL,
    `addressID` INT NULL
    );
SHOW tables;