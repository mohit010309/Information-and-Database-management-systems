CREATE TABLE `test`.`pets` (
	`petID` INT NOT NULL,
    `Name` VARCHAR(45) NULL,
    `Species` VARCHAR(45) NOT NULL,
    `ownerID` INT NULL
    );
SHOW tables;