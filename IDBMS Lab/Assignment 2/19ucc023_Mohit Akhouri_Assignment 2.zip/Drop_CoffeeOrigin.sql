ALTER TABLE products
DROP COLUMN CoffeeOrigin;
DESCRIBE products;