DELETE FROM products;
SELECT * FROM products;