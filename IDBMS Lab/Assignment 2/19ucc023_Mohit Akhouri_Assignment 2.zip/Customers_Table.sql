CREATE TABLE `coffee_store`.`customers` (
	`customerID` INT NOT NULL,
    `First_Name` VARCHAR(45),
    `Last_Name` VARCHAR(45),
    `Gender` ENUM('M','F') NOT NULL,
    `ContactNumber` VARCHAR(10) NULL,
    PRIMARY KEY (`customerID`)
    );
SHOW tables;
