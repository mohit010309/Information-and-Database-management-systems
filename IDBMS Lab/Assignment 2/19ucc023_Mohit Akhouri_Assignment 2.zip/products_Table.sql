CREATE TABLE `coffee_store`.`products` (
	`productID` INT NOT NULL,
    `Name` VARCHAR(45) NULL,
    `Price` FLOAT NOT NULL,
    PRIMARY KEY(`productID`)
    );
SHOW tables;
DROP TABLE orders;
