USE coffee_store;
DESCRIBE products;
-- DESCRIBE orders;
-- DESCRIBE customers;