INSERT INTO products(productID,Name,Price,CoffeeOrigin)
VALUES (1,'Espresso',2.50,'Brazil');
INSERT INTO products(productID,Name,Price,CoffeeOrigin)
VALUES (2,'Cappuccino',3.50,'CostaRica');
INSERT INTO products(productID,Name,Price,CoffeeOrigin)
VALUES (3,'Latte',4.50,'Italy');
SELECT * FROM products;