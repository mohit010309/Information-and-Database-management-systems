INSTRUCTIONS REGARDING EXECUTION OF QUERIES : 

1 - before deleting the table products , drop the foreign key constraint in the orders table otherwise it will give errors.

2 - CustomerID,orderID and productID are primary keys so we should not enter any duplicate values in this columns.

3 - After dropping column CoffeeOrigin , again add it because Last question of assignment requires the column CoffeeOrigin for values.

4 - Foreign keys are named as FK1 and FK2 , so wherever we drop foreign keys ,use these names.

