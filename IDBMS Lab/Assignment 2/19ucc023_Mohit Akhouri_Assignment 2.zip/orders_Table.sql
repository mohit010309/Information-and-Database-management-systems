CREATE TABLE `coffee_store`.`orders` (
	`orderID` INT NOT NULL,
    `productID` INT,
    `customerID` INT,
    `Date_Time` DATETIME,
     PRIMARY KEY(`orderID`),
     CONSTRAINT FK1 FOREIGN KEY (`productID`) REFERENCES products(`productID`),
     CONSTRAINT FK2 FOREIGN KEY (`customerID`) REFERENCES customers(`customerID`)
     );
SHOW tables;