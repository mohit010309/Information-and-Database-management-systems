ALTER TABLE products
ADD CoffeeOrigin VARCHAR(45) NULL;
DESCRIBE products;