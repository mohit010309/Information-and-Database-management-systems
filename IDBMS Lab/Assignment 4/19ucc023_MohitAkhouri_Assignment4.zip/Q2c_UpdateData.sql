UPDATE products
SET CoffeeOrigin='Columbia'
WHERE CoffeeOrigin='Brazil';
SELECT * FROM products;