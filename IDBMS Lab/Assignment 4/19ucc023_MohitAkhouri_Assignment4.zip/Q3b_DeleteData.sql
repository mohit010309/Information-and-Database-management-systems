DELETE FROM products
WHERE Price=3.50;
SELECT * FROM products;