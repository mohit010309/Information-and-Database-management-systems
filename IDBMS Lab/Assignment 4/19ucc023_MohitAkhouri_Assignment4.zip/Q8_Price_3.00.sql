SELECT * FROM products WHERE Price=3.00;
