INSERT INTO products(productID,Name,Price,CoffeeOrigin)
VALUES(1,'Espresso',2.50,'Brazil');
INSERT INTO products(productID,Name,Price,CoffeeOrigin)
VALUES(2,'Macchiato',3.00,'Brazil');
INSERT INTO products(productID,Name,Price,CoffeeOrigin)
VALUES(3,'Cappuccino',3.50,'Costa Rica');
INSERT INTO products(productID,Name,Price,CoffeeOrigin)
VALUES(4,'Latte',3.50,'Indonesia');
INSERT INTO products(productID,Name,Price,CoffeeOrigin)
VALUES(5,'Americano',3.00,'Brazil');
INSERT INTO products(productID,Name,Price,CoffeeOrigin)
VALUES(6,'Flat White',3.50,'Indonesia');
INSERT INTO products(productID,Name,Price,CoffeeOrigin)
VALUES(7,'Filter',3.00,'India');
SELECT * FROM products;
