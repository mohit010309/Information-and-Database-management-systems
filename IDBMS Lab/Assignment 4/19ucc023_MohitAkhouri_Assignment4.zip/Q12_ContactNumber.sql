SELECT * FROM customers
WHERE ContactNumber IS NULL;