CREATE TABLE `coffee_store`.`products` (
	`productID` INT NOT NULL AUTO_INCREMENT,
    `Name` VARCHAR(30) NOT NULL,
    `Price` DECIMAL(10,2) NULL,
    `CoffeeOrigin` VARCHAR(30),
    PRIMARY KEY(`productId`),
    CHECK(Price<=9.99)
    );
SHOW tables;