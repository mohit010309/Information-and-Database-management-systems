UPDATE products
SET Price=3.25,CoffeeOrigin='Ethiopia'
WHERE Name='Americano';
SELECT * FROM products;