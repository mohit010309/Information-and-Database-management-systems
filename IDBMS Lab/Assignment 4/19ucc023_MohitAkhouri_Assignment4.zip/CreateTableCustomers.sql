CREATE TABLE `coffee_store`.`customers` (
	`customerID` INT NOT NULL AUTO_INCREMENT,
    `First_Name` VARCHAR(30) NOT NULL,
    `Last_Name` VARCHAR(30) NULL,
    `Gender` ENUM('M','F') NOT NULL,
    `ContactNumber` VARCHAR(11) NULL,
    PRIMARY KEY(`customerID`),
    CHECK(Length(ContactNumber)=11)
    );
SHOW tables;