UPDATE products
SET CoffeeOrigin='Sri Lanka' 
WHERE productID=7;
SELECT * FROM PRODUCTS;