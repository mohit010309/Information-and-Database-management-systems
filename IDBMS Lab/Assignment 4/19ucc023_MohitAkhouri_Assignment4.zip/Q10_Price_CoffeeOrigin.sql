SELECT * FROM products WHERE Price=3.00 OR CoffeeOrigin='Columbia';
