CREATE TABLE `coffee_store`.`orders` (
 `orderID` INT NOT NULL AUTO_INCREMENT,
 `productID` INT NULL,
 `customerID` INT NULL,
 `Date_Time` DATETIME NULL,
 PRIMARY KEY(`orderID`),
  CONSTRAINT FK1 FOREIGN KEY(`productID`) REFERENCES products(`productID`),
  CONSTRAINT FK2 FOREIGN KEY(`customerID`) REFERENCES customers(`customerID`)
 );
 SHOW tables;
 
 