-- DESCRIBE products;
-- DESCRIBE customers;
DESCRIBE orders;