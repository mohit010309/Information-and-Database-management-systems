DELETE FROM products
WHERE Name='Flat White';
SELECT * FROM products;